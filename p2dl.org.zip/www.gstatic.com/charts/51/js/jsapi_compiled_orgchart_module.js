var gvjs_BU = "google-visualization-orgchart-connrow-";

function gvjs_CU(a) {
    gvjs_Qn.call(this, a);
    this.m = {};
    this.Z = null;
    this.D = gvjs_Oh();
    this.Of = new gvjs_$n;
    this.Jr = null
}
gvjs_o(gvjs_CU, gvjs_Qn);
gvjs_ = gvjs_CU.prototype;
gvjs_.Rd = function(a, b, c) {
    this.m = a = c || {};
    this.Z = b;
    if (!this.container) throw Error(gvjs_za);
    if (!b) throw Error(gvjs_as);
    b = new gvjs_3L(b, {
        W9: !1,
        X9: !1,
        v$: !1
    });
    this.Jr = new gvjs_4L(b, function(d) {
        return new gvjs_DU(d)
    });
    this.sE(this.Jr, a);
    gvjs_I(this, gvjs_i, {})
};

function gvjs_EU(a, b) {
    var c = [];
    a.Jr.VL(function(d, e) {
        e == b && c.push(d);
        return !d.collapsed && e < b
    }, a);
    c.sort(function(d, e) {
        return d.row - e.row
    });
    return c
}

function gvjs_FU(a, b) {
    var c = b.getChildren(),
        d = c.length;
    if (0 == d) b.x = a.v1++;
    else {
        for (var e = 0; e < d; e++) gvjs_FU(a, c[e]);
        b.x = (c[0].x + c[d - 1].x) / 2
    }
}
gvjs_.sE = function(a, b) {
    var c = this.container;
    this.v1 = 0;
    for (var d = gvjs_EU(this, 0), e = 0; e < d.length; e++) gvjs_FU(this, d[e]);
    d = b.size;
    "large" != d && "small" != d && (d = gvjs_dd);
    var f = this.D,
        g = f.J(gvjs_ss, {
            "class": "google-visualization-orgchart-table",
            dir: gvjs_Dv,
            cellpadding: "0",
            cellspacing: "0",
            align: gvjs_0
        }),
        h = f.J(gvjs_ts);
    f.appendChild(g, h);
    var k = 8 * this.v1 - 2,
        l = f.J(gvjs_vs, null);
    f.appendChild(h, l);
    for (var m = 0; m < k; m++) {
        var n = f.J(gvjs_us, {
            "class": "google-visualization-orgchart-space-" + d
        });
        f.appendChild(l, n)
    }
    a = a.getHeight() +
        1;
    for (l = 0; l < a; l++) {
        m = gvjs_EU(this, l);
        if (0 < l) {
            var p = [];
            for (var q = 0; q < m.length; q++) {
                var r = m[q];
                n = r.getParent();
                e = Math.round(8 * r.x + 3);
                n.x >= r.x ? ((n = p[e]) || (n = p[e] = {}), n.borderLeft = !0) : ((n = p[--e]) || (n = p[e] = {}), n.borderRight = !0)
            }
            gvjs_GU(this, p, k, h, gvjs_BU + d, d, b)
        }
        p = [];
        for (q = 0; q < m.length; q++) r = m[q], e = Math.round(8 * r.x), (n = p[e]) || (n = p[e] = {}), n.node = r, n.span = 6;
        gvjs_GU(this, p, k, h, "google-visualization-orgchart-noderow-" + d, d, b);
        if (l != a) {
            p = [];
            for (q = 0; q < m.length; q++) {
                r = m[q];
                var t = r.getChildren();
                if (0 < t.length &&
                    (e = Math.round(8 * r.x + 3), (n = p[e]) || (n = p[e] = {}), n.borderLeft = !0, !r.collapsed))
                    for (r = Math.round(8 * t[t.length - 1].x + 3), e = Math.round(8 * t[0].x + 3); e < r; e++)(n = p[e]) || (n = p[e] = {}), n.borderBottom = !0
            }
            gvjs_GU(this, p, k, h, gvjs_BU + d, d, b)
        }
    }
    f.qc(c);
    f.appendChild(c, g)
};

function gvjs_GU(a, b, c, d, e, f, g) {
    var h = g.nodeClass || "google-visualization-orgchart-node",
        k = a.D;
    e = k.J(gvjs_vs, {
        "class": e
    });
    k.appendChild(d, e);
    for (d = 0; d < c; d++) {
        var l = b[d],
            m = k.J(gvjs_us, null);
        if (!l) {
            l = {
                empty: !0
            };
            for (var n = d + 1; n < c && !b[n];) n++;
            l.span = n - d
        }(n = l.span) && 1 < n && (m.colSpan = n, d += n - 1);
        if (l.node) {
            l.node.Q4 = m;
            n = h + " google-visualization-orgchart-node-" + f;
            var p = l.node.row;
            null != p && (gvjs_G(m, gvjs_gd, gvjs_s(a.ZZ, a, p)), gvjs_G(m, gvjs_ld, gvjs_s(a.a_, a, p)), gvjs_G(m, gvjs_kd, gvjs_s(a.$Z, a, p)), a.m.allowCollapse &&
                gvjs_G(m, gvjs_du, gvjs_s(a.Upa, a, p)))
        } else n = "google-visualization-orgchart-linenode", l.borderLeft && (n += " google-visualization-orgchart-lineleft"), l.borderRight && (n += " google-visualization-orgchart-lineright"), l.borderBottom && (n += " google-visualization-orgchart-linebottom");
        n && (m.className = n, -1 < n.indexOf(h) && (g.color && (m.style.background = g.color), n = l.node && l.node.style)) && (n = gvjs_PA(n), m.style.cssText = gvjs_Ff(n));
        n = l.node ? l.node.lI : "\u00a0";
        l = l.node ? l.node.label : null;
        null != l && (m.title = l);
        g.allowHtml ?
            (l = gvjs_OA(n), gvjs_cg(m, l)) : k.appendChild(m, k.createTextNode(n));
        k.appendChild(e, m)
    }
}
gvjs_.getSelection = function() {
    return this.Of.getSelection()
};
gvjs_.setSelection = function(a) {
    var b = this.m,
        c = this.Of.setSelection(a);
    if (this.container) {
        a = b.selectedNodeClass || "google-visualization-orgchart-nodesel";
        for (var d = gvjs_bo(c.An), e = 0; e < d.length; e++) {
            var f = d[e],
                g = 0 <= f ? this.Jr.uw[f] || null : null;
            g && (f = g.Q4) && (gvjs_XC(f, a), b.color && (f.style.background = b.color), g = g.style) && (g = gvjs_PA(g), f.style.cssText = gvjs_Ff(g))
        }
        c = gvjs_bo(c.uB);
        for (e = 0; e < c.length; e++)
            if (f = c[e], g = 0 <= f ? this.Jr.uw[f] || null : null)
                if (f = g.Q4)
                    if (gvjs_VC(f, a), b.selectionColor && (f.style.background =
                            b.selectionColor), d = g.lwa) d = gvjs_PA(d), f.style.cssText = gvjs_Ff(d)
    }
};
gvjs_.ZZ = function(a) {
    a = gvjs_do(this.Of, a) ? null : [{
        row: a
    }];
    this.setSelection(a);
    gvjs_I(this, gvjs_k, {})
};
gvjs_.a_ = function(a) {
    gvjs_I(this, gvjs_7v, {
        row: a
    })
};
gvjs_.$Z = function(a) {
    gvjs_I(this, gvjs_6v, {
        row: a
    })
};
gvjs_.Upa = function(a) {
    var b = this.Jr.uw[a] || null;
    this.collapse(a, !(b && b.collapsed))
};
gvjs_.Boa = function() {
    return this.Jr.find(function(a) {
        return a.collapsed
    }).map(function(a) {
        return a.row
    })
};
gvjs_.Aoa = function(a) {
    a = this.Jr.uw[a] || null;
    if (!a) return [];
    a = a.getChildren();
    for (var b = [], c = 0; c < a.length; c++) b.push(a[c].row);
    return b
};
gvjs_.collapse = function(a, b) {
    var c = this.Jr.uw[a] || null;
    c && c.getChildren() && 0 != c.getChildren().length && (b && !c.collapsed || !b && c.collapsed) && (c.collapsed = b, this.D.qc(this.container), this.sE(this.Jr, this.m), gvjs_I(this, gvjs_i, {}), gvjs_I(this, "collapse", {
        collapsed: b,
        row: a
    }))
};
gvjs_.v1 = 0;

function gvjs_DU(a) {
    gvjs__L.call(this, a.getId(), a.getName());
    this.row = a.getId();
    this.lI = gvjs_1L(a);
    this.style = a.Ul(gvjs_Jd);
    this.lwa = a.Ul("selectedStyle");
    this.label = 3 == a.mb().$() ? a.Ha(2) : null;
    this.Q4 = this.x = null;
    this.collapsed = !1
}
gvjs_o(gvjs_DU, gvjs__L);
gvjs_q(gvjs_Ic, gvjs_CU, void 0);
gvjs_CU.prototype.draw = gvjs_CU.prototype.draw;
gvjs_CU.prototype.getSelection = gvjs_CU.prototype.getSelection;
gvjs_CU.prototype.setSelection = gvjs_CU.prototype.setSelection;
gvjs_CU.prototype.getChildrenIndexes = gvjs_CU.prototype.Aoa;
gvjs_CU.prototype.getCollapsedNodes = gvjs_CU.prototype.Boa;
gvjs_CU.prototype.collapse = gvjs_CU.prototype.collapse;