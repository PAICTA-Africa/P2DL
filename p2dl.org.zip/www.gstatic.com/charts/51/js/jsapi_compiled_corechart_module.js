var gvjs_iQ = "#990000",
    gvjs_jQ = "annotationText",
    gvjs_kQ = "certainty";
gvjs_iL.prototype.Jm = gvjs_V(70, function(a, b) {
    if (this.Xg === gvjs_fw) return this.av(a, b);
    throw Error(gvjs_4r);
});
gvjs_jL.prototype.Jm = gvjs_V(69, function(a, b) {
    return this.av(a, b)
});

function gvjs_lQ(a) {
    var b = new gvjs_OE;
    b.sa = function() {
        return a
    };
    return b
}

function gvjs_mQ(a) {
    gvjs_iL.call(this, a);
    this.cc(gvjs_d, gvjs_at, gvjs_S)
}
gvjs_o(gvjs_mQ, gvjs_iL);

function gvjs_nQ(a) {
    gvjs_iL.call(this, a);
    this.cc(gvjs_d, gvjs_4w, gvjs_S)
}
gvjs_o(gvjs_nQ, gvjs_iL);

function gvjs_oQ(a) {
    gvjs_iL.call(this, a);
    this.cc(gvjs_d, gvjs_f, gvjs_S, "sparkline")
}
gvjs_o(gvjs_oQ, gvjs_iL);

function gvjs_pQ(a) {
    gvjs_iL.call(this, a);
    this.cc(gvjs_d, gvjs_e, gvjs_S)
}
gvjs_o(gvjs_pQ, gvjs_iL);

function gvjs_qQ(a) {
    gvjs_iL.call(this, a);
    this.cc(gvjs_Dd)
}
gvjs_o(gvjs_qQ, gvjs_iL);
gvjs_qQ.prototype.Jm = function(a, b) {
    return this.av(a, b)
};

function gvjs_rQ(a) {
    gvjs_iL.call(this, a);
    this.cc(gvjs_yt)
}
gvjs_o(gvjs_rQ, gvjs_iL);

function gvjs_sQ(a) {
    gvjs_iL.call(this, a);
    this.cc(gvjs_d, gvjs_lt, gvjs_U)
}
gvjs_o(gvjs_sQ, gvjs_iL);
gvjs_sQ.prototype.Jm = function(a, b) {
    return this.av(a, b)
};

function gvjs_tQ(a) {
    gvjs_iL.call(this, a);
    this.cc(gvjs_d, gvjs_Ft, gvjs_S)
}
gvjs_o(gvjs_tQ, gvjs_iL);

function gvjs_uQ(a) {
    gvjs_iL.call(this, a);
    this.cc(gvjs_d, gvjs_lt, gvjs_S)
}
gvjs_o(gvjs_uQ, gvjs_iL);
gvjs_uQ.prototype.Jm = function(a, b) {
    return this.av(a, b)
};

function gvjs_vQ(a) {
    gvjs_iL.call(this, a);
    this.cc(gvjs_4u, gvjs_lt, gvjs_S)
}
gvjs_o(gvjs_vQ, gvjs_iL);
gvjs_q(gvjs_fc, gvjs_iL, void 0);
gvjs_iL.prototype.draw = gvjs_iL.prototype.draw;
gvjs_iL.prototype.clearChart = gvjs_iL.prototype.Jb;
gvjs_iL.prototype.getImageURI = gvjs_iL.prototype.ah;
gvjs_iL.prototype.getSelection = gvjs_iL.prototype.getSelection;
gvjs_iL.prototype.setSelection = gvjs_iL.prototype.setSelection;
gvjs_iL.prototype.dump = gvjs_iL.prototype.dump;
gvjs_iL.prototype.getChartLayoutInterface = gvjs_iL.prototype.Ql;
gvjs_iL.prototype.getContainer = gvjs_iL.prototype.getContainer;
gvjs_iL.prototype.setAction = gvjs_iL.prototype.xh;
gvjs_iL.prototype.getAction = gvjs_iL.prototype.ng;
gvjs_iL.prototype.removeAction = gvjs_iL.prototype.th;
gvjs_q(gvjs_4b, gvjs_mQ, void 0);
gvjs_mQ.prototype.draw = gvjs_mQ.prototype.draw;
gvjs_mQ.prototype.clearChart = gvjs_mQ.prototype.Jb;
gvjs_mQ.prototype.getImageURI = gvjs_mQ.prototype.ah;
gvjs_mQ.prototype.getSelection = gvjs_mQ.prototype.getSelection;
gvjs_mQ.prototype.setSelection = gvjs_mQ.prototype.setSelection;
gvjs_mQ.prototype.setAction = gvjs_mQ.prototype.xh;
gvjs_mQ.prototype.getAction = gvjs_mQ.prototype.ng;
gvjs_mQ.prototype.removeAction = gvjs_mQ.prototype.th;
gvjs_q(gvjs_5b, gvjs_sQ, void 0);
gvjs_sQ.prototype.computeDiff = gvjs_sQ.prototype.Jm;
gvjs_sQ.prototype.draw = gvjs_sQ.prototype.draw;
gvjs_sQ.prototype.clearChart = gvjs_sQ.prototype.Jb;
gvjs_sQ.prototype.getImageURI = gvjs_sQ.prototype.ah;
gvjs_sQ.prototype.getSelection = gvjs_sQ.prototype.getSelection;
gvjs_sQ.prototype.setSelection = gvjs_sQ.prototype.setSelection;
gvjs_sQ.prototype.setAction = gvjs_sQ.prototype.xh;
gvjs_sQ.prototype.getAction = gvjs_sQ.prototype.ng;
gvjs_sQ.prototype.removeAction = gvjs_sQ.prototype.th;
gvjs_q(gvjs_6b, gvjs_rQ, void 0);
gvjs_rQ.prototype.draw = gvjs_rQ.prototype.draw;
gvjs_rQ.prototype.clearChart = gvjs_rQ.prototype.Jb;
gvjs_rQ.prototype.getImageURI = gvjs_rQ.prototype.ah;
gvjs_rQ.prototype.getSelection = gvjs_rQ.prototype.getSelection;
gvjs_rQ.prototype.setSelection = gvjs_rQ.prototype.setSelection;
gvjs_rQ.prototype.setAction = gvjs_rQ.prototype.xh;
gvjs_rQ.prototype.getAction = gvjs_rQ.prototype.ng;
gvjs_rQ.prototype.removeAction = gvjs_rQ.prototype.th;
gvjs_q(gvjs_8b, gvjs_tQ, void 0);
gvjs_tQ.prototype.draw = gvjs_tQ.prototype.draw;
gvjs_tQ.prototype.clearChart = gvjs_tQ.prototype.Jb;
gvjs_tQ.prototype.getImageURI = gvjs_tQ.prototype.ah;
gvjs_tQ.prototype.getSelection = gvjs_tQ.prototype.getSelection;
gvjs_tQ.prototype.setSelection = gvjs_tQ.prototype.setSelection;
gvjs_tQ.prototype.setAction = gvjs_tQ.prototype.xh;
gvjs_tQ.prototype.getAction = gvjs_tQ.prototype.ng;
gvjs_tQ.prototype.removeAction = gvjs_tQ.prototype.th;
gvjs_q(gvjs_rc, gvjs_vQ, void 0);
gvjs_vQ.prototype.draw = gvjs_vQ.prototype.draw;
gvjs_vQ.prototype.clearChart = gvjs_vQ.prototype.Jb;
gvjs_vQ.prototype.getImageURI = gvjs_vQ.prototype.ah;
gvjs_vQ.prototype.getSelection = gvjs_vQ.prototype.getSelection;
gvjs_vQ.prototype.setSelection = gvjs_vQ.prototype.setSelection;
gvjs_vQ.prototype.setAction = gvjs_vQ.prototype.xh;
gvjs_vQ.prototype.getAction = gvjs_vQ.prototype.ng;
gvjs_vQ.prototype.removeAction = gvjs_vQ.prototype.th;
gvjs_q(gvjs_cc, gvjs_uQ, void 0);
gvjs_uQ.prototype.computeDiff = gvjs_uQ.prototype.Jm;
gvjs_uQ.prototype.draw = gvjs_uQ.prototype.draw;
gvjs_uQ.prototype.clearChart = gvjs_uQ.prototype.Jb;
gvjs_uQ.prototype.getImageURI = gvjs_uQ.prototype.ah;
gvjs_uQ.prototype.getSelection = gvjs_uQ.prototype.getSelection;
gvjs_uQ.prototype.setSelection = gvjs_uQ.prototype.setSelection;
gvjs_uQ.prototype.setAction = gvjs_uQ.prototype.xh;
gvjs_uQ.prototype.getAction = gvjs_uQ.prototype.ng;
gvjs_uQ.prototype.removeAction = gvjs_uQ.prototype.th;
gvjs_q(gvjs_ec, gvjs_rL, void 0);
gvjs_rL.prototype.draw = gvjs_rL.prototype.draw;
gvjs_rL.prototype.clearChart = gvjs_rL.prototype.Jb;
gvjs_rL.prototype.getImageURI = gvjs_rL.prototype.ah;
gvjs_rL.prototype.getSelection = gvjs_rL.prototype.getSelection;
gvjs_rL.prototype.setSelection = gvjs_rL.prototype.setSelection;
gvjs_rL.prototype.setAction = gvjs_rL.prototype.xh;
gvjs_rL.prototype.getAction = gvjs_rL.prototype.ng;
gvjs_rL.prototype.removeAction = gvjs_rL.prototype.th;
gvjs_q(gvjs_zc, gvjs_pQ, void 0);
gvjs_pQ.prototype.draw = gvjs_pQ.prototype.draw;
gvjs_pQ.prototype.clearChart = gvjs_pQ.prototype.Jb;
gvjs_pQ.prototype.getImageURI = gvjs_pQ.prototype.ah;
gvjs_pQ.prototype.getSelection = gvjs_pQ.prototype.getSelection;
gvjs_pQ.prototype.setSelection = gvjs_pQ.prototype.setSelection;
gvjs_pQ.prototype.setAction = gvjs_pQ.prototype.xh;
gvjs_pQ.prototype.getAction = gvjs_pQ.prototype.ng;
gvjs_pQ.prototype.removeAction = gvjs_pQ.prototype.th;
gvjs_q(gvjs_Jc, gvjs_jL, void 0);
gvjs_jL.prototype.computeDiff = gvjs_jL.prototype.Jm;
gvjs_jL.prototype.draw = gvjs_jL.prototype.draw;
gvjs_jL.prototype.clearChart = gvjs_jL.prototype.Jb;
gvjs_jL.prototype.getImageURI = gvjs_jL.prototype.ah;
gvjs_jL.prototype.getSelection = gvjs_jL.prototype.getSelection;
gvjs_jL.prototype.setSelection = gvjs_jL.prototype.setSelection;
gvjs_jL.prototype.setAction = gvjs_jL.prototype.xh;
gvjs_jL.prototype.getAction = gvjs_jL.prototype.ng;
gvjs_jL.prototype.removeAction = gvjs_jL.prototype.th;
gvjs_q(gvjs_Nc, gvjs_qQ, void 0);
gvjs_qQ.prototype.computeDiff = gvjs_qQ.prototype.Jm;
gvjs_qQ.prototype.draw = gvjs_qQ.prototype.draw;
gvjs_qQ.prototype.clearChart = gvjs_qQ.prototype.Jb;
gvjs_qQ.prototype.getImageURI = gvjs_qQ.prototype.ah;
gvjs_qQ.prototype.getSelection = gvjs_qQ.prototype.getSelection;
gvjs_qQ.prototype.setSelection = gvjs_qQ.prototype.setSelection;
gvjs_qQ.prototype.setAction = gvjs_qQ.prototype.xh;
gvjs_qQ.prototype.getAction = gvjs_qQ.prototype.ng;
gvjs_qQ.prototype.removeAction = gvjs_qQ.prototype.th;
gvjs_q(gvjs_Pc, gvjs_oQ, void 0);
gvjs_oQ.prototype.draw = gvjs_oQ.prototype.draw;
gvjs_oQ.prototype.clearChart = gvjs_oQ.prototype.Jb;
gvjs_oQ.prototype.getImageURI = gvjs_oQ.prototype.ah;
gvjs_oQ.prototype.getSelection = gvjs_oQ.prototype.getSelection;
gvjs_oQ.prototype.setSelection = gvjs_oQ.prototype.setSelection;
gvjs_oQ.prototype.setAction = gvjs_oQ.prototype.xh;
gvjs_oQ.prototype.getAction = gvjs_oQ.prototype.ng;
gvjs_oQ.prototype.removeAction = gvjs_oQ.prototype.th;
gvjs_q(gvjs_Qc, gvjs_nQ, void 0);
gvjs_nQ.prototype.draw = gvjs_nQ.prototype.draw;
gvjs_nQ.prototype.clearChart = gvjs_nQ.prototype.Jb;
gvjs_nQ.prototype.getImageURI = gvjs_nQ.prototype.ah;
gvjs_nQ.prototype.getSelection = gvjs_nQ.prototype.getSelection;
gvjs_nQ.prototype.setSelection = gvjs_nQ.prototype.setSelection;
gvjs_nQ.prototype.setAction = gvjs_nQ.prototype.xh;
gvjs_nQ.prototype.getAction = gvjs_nQ.prototype.ng;
gvjs_nQ.prototype.removeAction = gvjs_nQ.prototype.th;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
function gvjs_wQ(a, b, c, d) {
    gvjs_qC.call(this, a, b, c, null, d)
}
gvjs_t(gvjs_wQ, gvjs_qC);
gvjs_wQ.prototype.rg = function() {
    do gvjs_wQ.G.next.call(this); while (-1 == this.tj);
    return this.node
};
gvjs_wQ.prototype.next = gvjs_wQ.prototype.rg;
gvjs_dh(gvjs_b);

function gvjs_xQ(a) {
    return (new gvjs_wm).cd().sanitize(a)
};